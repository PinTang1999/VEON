# VEON environment installer: V100 + CUDA 10.2

Extract this archive in your existing VEON repository root:

    unzip veon-env-installers.zip

Run on a Linux x86_64 GPU server with Conda, NVIDIA driver,
CUDA Toolkit 10.2 (including nvcc), and matching GCC/G++ 5-8.
The Toolkit is required to compile BEVPoolv2; Conda cudatoolkit
by itself does not provide nvcc.

From the VEON repository root, run:

    CUDA_HOME=/usr/local/cuda-10.2 bash tools/install_env.sh veon-cu102

Replace CUDA_HOME with the actual CUDA Toolkit path if different.
No separate conda create or manual PyTorch installation is needed.

After the installer succeeds:

    source "$(conda info --base)/etc/profile.d/conda.sh"
    conda activate veon-cu102

The installer pins Python 3.8, PyTorch 1.10.1 (CUDA 10.2),
torchvision 0.11.2, MMCV-full 1.6.0, MMDet 2.25.1,
MMSeg 0.25.0, Detectron2 0.6, OpenCLIP 2.16.0 and timm 0.6.12.
The file requirements/veon-cu113.txt is intentionally shared
between the CUDA 10.2 and 11.3 profiles; CUDA wheels are selected
separately by the installer.

The final check imports models/datasets/training entrypoints and
runs CUDA NMS plus BEVPoolv2 forward/backward. Success prints PASS.
This does not verify full model training or benchmark results.
Datasets and pretrained checkpoints must be prepared separately
as described in the VEON README.

Verified locally: shell/Python syntax, dependency resolution for
Python packages, mocked version/compiler/GPU profile selection.
A full installation/training run on a V100 has not been verified.
